=== Vbee Text to Speech ===
Contributors: mktvbee
Tags: text to speech, tts, audio player
Requires at least: 5.0.1
Tested up to: 6.0
Requires PHP: 7.0
Stable tag: trunk 

**Vbee AI Voice Studio** - Nền tảng chuyển văn bản thành giọng nói đầy cảm xúc với chất lượng phòng thu.
== Description ==

**Plugin Vbee Text To Speech là** công cụ giúp bạn chuyển đổi các nội dung chữ viết, bài đăng trên blog thành âm thanh để người dùng có thể nghe nội dung của bạn. Plugin sử dụng công nghệ của Vbee Text To Speech hiện đại và trình phát âm thanh thân thiện, giúp bạn tạo, nhúng và phân phối các bài viết của mình ở định dạng âm thanh vô cùng nhanh chóng

**Hướng dẫn sử dụng Plugin Vbee trên Wordpress**
= 1. Tạo tài khoản https://vbee.vn =
* Truy cập API https://api.vbee.vn/apps
* Mua 1 gói cước bất kỳ
= 2. Tạo App_id tại Khởi tạo ứng dụng =
* Điền tên API
* Chọn hạn dùng API
* Tạo Token
= 3. Cài đặt Plugin trên Wordpress với các trường dữ liệu bắt buộc: =
* API Address URL (mặc định là: https://vbee.vn/api/v1/tts)
* App ID vừa tạo
* Token vừa tạo
* Bit Rate (mặc định là: 128)
* Rate (Tốc độ giọng đọc, mặc định là: 1.0)
= 4. Tạo Audio cho bài viết =
* Truy cập Bài viết > Tất cả bài viết > ấn “Tạo audio” tại phần Tiêu Đề.

Với 3 giọng đọc nam/nữ đầy đủ 3 miền Bắc-Trung-Nam, chất lượng từ Nâng Cao đến Cao Cấp của Vbee, website bạn sẽ có ngay bộ sưu tập giọng đọc MC vô cùng tự nhiên và truyền cảm để phát các nội dung âm thanh. 

== Installation ==

**Hướng dẫn sử dụng Plugin Vbee trên Wordpress**
= 1. Tạo tài khoản https://vbee.vn =
* Truy cập API https://api.vbee.vn/apps
* Mua 1 gói cước bất kỳ
= 2. Tạo App_id tại Khởi tạo ứng dụng =
* Điền tên API
* Chọn hạn dùng API
* Tạo Token
= 3. Cài đặt Plugin trên Wordpress với các trường dữ liệu bắt buộc: =
* API Address URL (mặc định là: https://vbee.vn/api/v1/tts)
* App ID vừa tạo
* Token vừa tạo
* Bit Rate (mặc định là: 128)
* Rate (Tốc độ giọng đọc, mặc định là: 1.0)
= 4. Tạo Audio cho bài viết =
* Truy cập Bài viết > Tất cả bài viết > ấn “Tạo audio” tại phần Tiêu Đề.

== Frequently asked questions ==



== Screenshots ==

1. Thiết lập trong Plugin
2. Tạo App-id trên vbee.vn
3. Quản lý sản lượng

== Changelog ==



== Upgrade notice ==



== Arbitrary section 1 ==


